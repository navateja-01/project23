import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule,Routes} from '@angular/router'
import {FormsModule} from '@angular/forms'
import { AppComponent } from './app.component';
import { ProComponent } from './pro/pro.component';
import { HttpClientModule } from '@angular/common/http';
import { EditComponent } from './edit/edit.component';

const app:Routes = [
  {path:"edit",component:EditComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    ProComponent,
    EditComponent
  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule,RouterModule.forRoot(app)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
