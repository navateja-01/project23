import { Injectable } from '@angular/core';
import {Product} from './product';
import {HttpClient} from '@angular/common/http'
import { Observable } from 'rxjs/Observable';
@Injectable()
export class ProductService {
  constructor(private http:HttpClient) { }
  proArr2:Product[]=[]
  getProductDetails():any{
    
    return this.http.get('/assets/Product.json')
  }

}
