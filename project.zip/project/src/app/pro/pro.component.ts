import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import {Product}from '../product'
@Component({
  selector: 'app-pro',
  templateUrl: './pro.component.html',
  styleUrls: ['./pro.component.css'],
  providers:[ProductService]
})
export class ProComponent implements OnInit {
 proArr:Product[]=[];
 p:Product = new Product();
  constructor(private productservice:ProductService) { }

  ngOnInit() {
    this.productservice.getProductDetails().subscribe((m:Product[])=>this.proArr=m);
  }

  add(p:Product)
  {
      this.proArr.push(p);
  }
 
  delete(i:number):any{
    return this.proArr.splice(i,1);
  }
  edit(p:Product[])
  {
    Object.assign(this.p,p);
    
  }
submit()
{
  // this.proArr =this.productservice.submit(this.p);
  this.proArr.map((x)=>{
    if(x.id ==this.p.id)
    {
      x.Pdescription=this.p.Pdescription
      x.Pname=this.p.Pname
      x.Pprice=this.p.Pprice

    }
  })
}

}
