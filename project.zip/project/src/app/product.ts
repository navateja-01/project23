export class Product {
    id: number;
    Pname: string;
    Pdescription: string;
    Pprice: number;
}
