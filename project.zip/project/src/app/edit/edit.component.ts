import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProComponent } from '../pro/pro.component';


@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
p:Product=new Product();
  constructor(private pr:ProComponent) { }

  ngOnInit() {
  }
addDetails()
{
  this.pr.add(this.p)
  this.p = new Product();

}

}
